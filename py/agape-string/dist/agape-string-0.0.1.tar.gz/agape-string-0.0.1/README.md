# Agape

String manipulation

## Testing

```
python test.py
```

## Build

```
python setup.py sdist
```

## License

Copyright (C) 2021 Maverik Minett

The (MIT) license.